package com.example.bryan.tasknew_project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    // VARIABLES //
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private TabItem tab1;
    private TabItem tab2;
    private PagerAdapter pagerAdapter;
    private ViewPager viewPager;

    // VARIABLES  fot the colors//
    Button mRedColor;
    Button mGreenColor;
    Button mYellowColor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //   mRedColor = ( Button) findViewById( R.id.checkbox1 );
        //  mGreenColor = ( Button) findViewById( R.id.checkbox2 );
        //   mYellowColor = ( Button) findViewById( R.id.checkbox3 );

        // Create an instance of the tab layout from the view.
        tabLayout = findViewById(R.id.tabLayout);
        tab1 = findViewById(R.id.tab1);
        tab2 = findViewById(R.id.tab2);
        viewPager = findViewById(R.id.pager);

        pagerAdapter = new PagerAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(pagerAdapter);

        //Set the tabs to fill the entire layout.
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);


        // Using PagerAdapter to manage page views in fragments.
        // Each page is represented by its own fragment.
        // This is another example of the adapter pattern

        // Setting a listener for clicks.

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));


        /// tHIS METHODS ARE IMPLEMENTS BY  tablayoutonpagechangelistener
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {


            @Override
            public void onTabSelected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

   /// call the menu.xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {

            // calling the setting  activity
            case R.id.action_settings:
                displayToast("Settings Click");
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                return true;
            /// calling the second activity
            case R.id.action_colors:
                displayToast(" colors was Click"); /// COLLING THE DISPLAY METHOD ON THE BOTTOM
                Intent intent1 = new Intent(this, Main2Activity.class);
                startActivity(intent1);
                return true;

            case R.id.redColor:
                displayToast(" Red was Click"); /// COLLING THE DISPLAY METHOD ON THE BOTTOM
             //   mRedColor.setBackgroundColor(getResources().getColor(R.color.colorRed));
                toolbar.setBackgroundColor( getResources().getColor( R.color.colorRed ) );
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setStatusBarColor(getResources().getColor(R.color.colorRed));
                }
                storeColor(getResources().getColor(R.color.colorRed));
                return true;

            case R.id.greenColor:
                displayToast(" Green was Click"); /// COLLING THE DISPLAY METHOD ON THE BOTTOM
            //    mGreenColor.setBackgroundColor(getResources().getColor(R.color.colorGreen));
                 toolbar.setBackgroundColor( getResources().getColor( R.color.colorGreen ) );
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setStatusBarColor(getResources().getColor(R.color.colorGreen));
                }
                storeColor(getResources().getColor(R.color.colorGreen));
                return true;

            case R.id.yellowColor:
                displayToast(" yellow was Click"); /// COLLING THE DISPLAY METHOD ON THE BOTTOM
              //  mYellowColor.setBackgroundColor(getResources().getColor(R.color.colorYellow));
                 toolbar.setBackgroundColor( getResources().getColor( R.color.colorYellow ) );
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setStatusBarColor(getResources().getColor(R.color.colorYellow));
                }
                storeColor(getResources().getColor(R.color.colorYellow));
                return true;

            default:
        }
        return super.onOptionsItemSelected(item);
    }


    private void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }

    ///// COLOR METHODS store the colors in the sharedpreferences
    private void storeColor(int color) {
        SharedPreferences mSharedPreferences = getSharedPreferences("ToolbarColor", MODE_PRIVATE);
        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
        mEditor.putInt("color", color);/// THE KEY
        mEditor.apply();
    }

    // get the colors
    private int getColor() {
        SharedPreferences mSharedPreferences = getSharedPreferences("ToolbarColor", MODE_PRIVATE);
        // COLOR KEY VALUE AND DAFAULT VALUE COLOR PRIMATY IN CASE IT HAS NO COLOR
        int selectedColor = mSharedPreferences.getInt("color", getResources().getColor(R.color.colorPrimary));
        return selectedColor;
    }
}