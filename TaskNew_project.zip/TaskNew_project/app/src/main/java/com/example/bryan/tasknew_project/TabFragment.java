package com.example.bryan.tasknew_project;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class TabFragment extends Fragment {


    // VARIABLES //
    WordListHelper object; // OBJECT FROM THE SQLITE CLASS
    ArrayAdapter<String> adapter; // the library adapter
    ArrayList<String> list1;
    ListView listview;


    public TabFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate( R.layout.tab_fragment, container, false );
        ///it give visibility to the menu
        setHasOptionsMenu( true );

        // initial  the class
        object = new WordListHelper( getActivity() );

        listview = view.findViewById( R.id.list_item );
        ///
        list1 = new ArrayList<String>();
        adapter = new ArrayAdapter<String>( getActivity(), android.R.layout.simple_list_item_1, list1 );

        // METHOD LOAD LIST //
        loadTaskList();

        // DELETE FUNCTION //
        ///how to errase a index in the array list
        deleteTask();

        listview.setAdapter( adapter );
        adapter.notifyDataSetChanged();

        // Inflate the layout for this fragment
        return view;
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //     inflater.inflate( R.menu.menu_main, menu );
        super.onCreateOptionsMenu( menu, inflater );
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {
            case R.id.action_add:
                Toast.makeText( getActivity(), "ADD BUTTON WAS CLICKED", Toast.LENGTH_SHORT ).show();
                final EditText taskEditText = new EditText( getActivity() );
                AlertDialog dialog = new AlertDialog.Builder( getActivity() )

                        // SETS THE TITLE FOR THE ALERT DIALOG BOX //
                        .setTitle( "Task" )

                        // SETS THE MESSAGE
                        .setMessage( "Personal Task" )
                        .setView( taskEditText )
                        .setPositiveButton("Add_Message", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                // STRING VARIABLE //
                                String task = String.valueOf( taskEditText.getText() );

                                // INSERTING INTO THE NEXT ROW THATS EMPTY //
                                object.insertTask( task );

                                // LOADING THE LIST BACK T THE LISTVIEW //
                                loadTaskList();
                            }
                        } )
                        .setNegativeButton( "Cancel", null )
                        .create();
                dialog.show();
                return true;


            case R.id.action_Camara:
                Toast.makeText( getActivity(), "Camara BUTTON WAS CLICKED", Toast.LENGTH_SHORT ).show();
                Intent intent1 = new Intent( MediaStore.ACTION_IMAGE_CAPTURE );
                startActivity( intent1 );
                return true;

        }
        return super.onOptionsItemSelected( item );
    }

    private void loadTaskList() {

        // CREATING AN ARRAY LIST OF TASK OR LIST ITEMS AND STORING IT INTO THE LIST OF THE DATABASE //
        ArrayList<String> taskList = object.getTaskList();

        // CHECKING IF THE ADAPTER IS NULL //
        if (adapter == null) {
            Log.d( "Tab1", "ADAPTER IS NULL" );

            // IF IT IS NULL, SET A NEW ADAPTER WITH NEW VALUES //
            adapter = new ArrayAdapter<String>( getActivity(), android.R.layout.simple_list_item_1, list1 );

            // SETTING THE ADAPTER //
            listview.setAdapter( adapter );
            adapter.notifyDataSetChanged();
        }
        // OR WE JUST WILL CLEAR THE ADAPTER AND ...  //



        else {
            Log.d( "Tab1", "ADAPTER IS GOOD" );
            String e = taskList.get( taskList.size() - 1 );
            adapter.add( String.valueOf( e ) );


            if (list1.isEmpty()) {
                Log.d( "Tab1", "LIST IS EMPTY" );

            } else {
//                Log.d( "Tab1", "LIST HAS TASKS" );
//                String e = taskList.get( taskList.size() - 1 );
//                adapter.add( String.valueOf( e ) );


            }

        }
    }

    private void deleteTask(){

        // SETTING THE LIST WHEN IS HOLD TO BE DELETED //
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                // DELETE THE ITEM //
                list1.remove(position);

                adapter.notifyDataSetChanged();

                // SHOWING A TOAST TO THE USER //
                Toast.makeText(getActivity(), "item deleted", Toast.LENGTH_SHORT).show();

                return false;
            }
        });

        listview.setAdapter(adapter);
    }

}




