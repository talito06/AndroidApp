package com.example.bryan.tasknew_project;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends Activity {

    //Variable//
    Button mRedColor;
    Button mGreenColor;
    Button mYellowColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //initialize buttons //

        mRedColor = (Button) findViewById( R.id.checkbox1 );
        mGreenColor = (Button) findViewById( R.id.checkbox2 );
        mYellowColor = (Button) findViewById( R.id.checkbox3 );


        // if the color inside the preference is not equal to the color
        //colorprimary set the color to the toolbar
        if (getColor() != getResources().getColor( R.color.colorPrimary )) {


            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getWindow().setStatusBarColor( getColor() );// using the getcolor method
            }
        }

        mRedColor.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // SETTING THE BUTTON BACKGROUND TO RED COLOR, PASSING THE RED COLOR
                mRedColor.setBackgroundColor( getResources().getColor( R.color.colorRed ) );

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setStatusBarColor( getResources().getColor( R.color.colorRed ) );
                }
                storeColor(getResources().getColor(R.color.colorRed));/// CALLING THE STOREMETHOD
            }
            //  calling the method storecolor and passing the color red
            //  storeColor(getResources().getColor(R.color.colorRed));
        } );

        mGreenColor.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) { // SAME AS ABOVE
                mGreenColor.setBackgroundColor( getResources().getColor( R.color.colorGreen ) );
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setStatusBarColor( getResources().getColor( R.color.colorGreen ) );
                }
                storeColor(getResources().getColor(R.color.colorGreen));
            }
            //  storeColor(getResources().getColor(R.color.colorGreen));
        } );

        mYellowColor.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {   // SAME AS ABOVE

                mYellowColor.setBackgroundColor( getResources().getColor( R.color.colorYellow ) );

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    getWindow().setStatusBarColor( getResources().getColor( R.color.colorYellow ) );
                }
                storeColor(getResources().getColor(R.color.colorYellow));
            }
            //    storeColor(getResources().getColor(R.color.colorYellow));
        } );
    }
    ///// COLOR METHODS
    private void storeColor(int color) {
        SharedPreferences mSharedPreferences = getSharedPreferences( "ToolbarColor", MODE_PRIVATE );
        SharedPreferences.Editor mEditor = mSharedPreferences.edit();
        mEditor.putInt( "color", color );/// THE KEY
        mEditor.apply();
    }

    private int getColor() {
        SharedPreferences mSharedPreferences = getSharedPreferences( "ToolbarColor", MODE_PRIVATE );
        /// COLOR KEY VALUE AND DAFAULT VALUE COLOR PRIMATY IN CASE IT HAS NO COLOR
        int selectedColor = mSharedPreferences.getInt( "color", getResources().getColor(R.color.colorPrimary) );
        return selectedColor;
    }
}
